# USER ACCEPTANCE REVIEW

## Job ID

## Reviewed Output

## Acceptance Result
ACCEPTED / ACCEPTED_WITH_NOTES / REVISION_REQUIRED / REJECTED

## What Works

## What Must Change

## New Tasks Created

## Tasks Removed

## Tasks Modified

## Reviewed At
YYMMDDHH:mm:ss
