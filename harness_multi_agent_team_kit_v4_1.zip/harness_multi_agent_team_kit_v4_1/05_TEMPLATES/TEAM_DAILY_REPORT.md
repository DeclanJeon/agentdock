# Team Daily Report

- Team:
- Date: YYMMDD
- Reported At: YYMMDDHH:mm:ss
- Reporter:

## Completed Today

| Task ID | Summary | Completed At | Output |
|---|---|---|---|
|  |  | YYMMDDHH:mm:ss |  |

## In Progress

| Task ID | Status | Next Step | Blocker |
|---|---|---|---|
|  |  |  |  |

## Task Changes

| Timestamp | Task ID | Change Type | Summary |
|---|---|---|---|
| YYMMDDHH:mm:ss |  | ADDED / REMOVED / MODIFIED |  |

## Delegations

| To | Reason | Status |
|---|---|---|
|  |  |  |

## Risks

-
