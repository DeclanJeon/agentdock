# Task Brief

- Task ID:
- Requester:
- Owner:
- Priority: P0 / P1 / P2 / P3
- Status: TODO / DOING / BLOCKED / DONE

## Goal


## Background


## Scope

### In Scope

- 

### Out of Scope

- 

## Required Teams

- CEO:
- PM:
- Business:
- Marketing:
- Architecture:
- Design:
- Development:
- QA:
- DevOps:
- Legal/Risk:

## Deliverables

- 

## Acceptance Criteria

- [ ] 

## Constraints

- 

## Risks

- 

## Next Receiver
