# Sequence Diagram

- Feature:
- Scenario:
- Owner: Architecture Team
- Created At: YYMMDDHH:mm:ss
- Updated At: YYMMDDHH:mm:ss

## Main Scenario

```mermaid
sequenceDiagram
  participant U as User
  participant FE as Frontend
  participant API as API Server
  participant DB as Database

  U->>FE: Action
  FE->>API: Request
  API->>DB: Query
  DB-->>API: Result
  API-->>FE: Response
  FE-->>U: Render result
```

## Notes

- 

## Failure Scenario

```mermaid
sequenceDiagram
  participant FE as Frontend
  participant API as API Server
  FE->>API: Request
  API-->>FE: Error response
```
