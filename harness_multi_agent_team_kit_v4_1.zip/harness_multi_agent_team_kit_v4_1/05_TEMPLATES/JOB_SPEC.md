# Job Spec

- Job ID:
- Job Name:
- Created At: YYMMDDHH:mm:ss
- Created By:
- Owner:
- Status: REQUESTED / TRIAGED / ASSIGNED / IN_PROGRESS / DONE

## Goal


## Business Context


## Success Criteria

- [ ]
- [ ]

## Initial Task Breakdown

| Task ID | Task Name | Owner Team | Required Agent Count | Status |
|---|---|---|---|---|
|  |  |  |  |  |

## Current Task Breakdown

| Task ID | Task Name | Owner Team | Required Agent Count | Status |
|---|---|---|---|---|
|  |  |  |  |  |

## Change Summary

- Added:
- Removed:
- Modified:

## Final Deliverables

-
