# Completion Report

- Task ID:
- Parent Job ID:
- Team:
- Agent:
- Started At: YYMMDDHH:mm:ss
- Completed At: YYMMDDHH:mm:ss
- Final Status: DONE / PARTIAL / BLOCKED

## 1. Original Job Composition

처음 job/task가 어떻게 구성되어 있었는지 기록한다.

```txt
Job:
Tasks:
- 
- 
```

## 2. Final Job Composition

완료 시점의 최종 job/task 구성을 기록한다.

```txt
Job:
Tasks:
- 
- 
```

## 3. What Was Completed

- [x]
- [x]

## 4. Added Tasks

| Task ID | Reason | Owner | Status |
|---|---|---|---|
|  |  |  |  |

## 5. Removed Tasks

| Task ID | Reason | Approved By |
|---|---|---|
|  |  |  |

## 6. Modified Tasks

| Task ID | Before | After | Reason |
|---|---|---|---|
|  |  |  |  |

## 7. Files Created / Modified

| File | Action | Purpose |
|---|---|---|
|  | CREATED / MODIFIED |  |

## 8. Decisions Made

- 

## 9. Risks / Issues

- 

## 10. Next Receiver

- Team:
- Agent:
- Reason:
- Required Action:
