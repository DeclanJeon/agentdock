# USER INTENT BRIEF

## Raw User Request

## Interpreted Goal

## Real Problem

## Desired Output

## Success Criteria

## Constraints

## Non-goals

## Questions for User

## Approved At
YYMMDDHH:mm:ss
