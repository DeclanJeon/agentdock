# SCOPE DEFINITION

## In Scope

## Out of Scope

## Assumptions

## Constraints

## Dependencies

## Risks

## Open Questions

## Approval

- Approved By:
- Approved At: YYMMDDHH:mm:ss
