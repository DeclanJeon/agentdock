# Flow Diagram

- Feature:
- Owner: Architecture Team
- Created At: YYMMDDHH:mm:ss
- Updated At: YYMMDDHH:mm:ss

## User / System Flow

```mermaid
flowchart TD
  A[Start] --> B{Condition}
  B -->|Yes| C[Action]
  B -->|No| D[Alternative]
  C --> E[End]
  D --> E
```

## Flow Notes

- 

## Edge Flow

-
