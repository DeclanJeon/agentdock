# ADR-0000: Title

- Status: Proposed / Accepted / Deprecated
- Date:
- Owner:

## Context


## Decision


## Alternatives Considered

| Option | Pros | Cons |
|---|---|---|
|  |  |  |

## Consequences

### Positive

- 

### Negative

- 

## Impacted Teams

- PM:
- Design:
- Development:
- QA:
- DevOps:
