# HANDOFF REVIEW

## Review ID
REVIEW-YYMMDD-000

## Handoff File

## From Team

## To Team

## Job ID

## Task ID

## Review Decision
ACCEPTED / NEEDS_CLARIFICATION / REVISION_REQUIRED / REJECTED_WRONG_TEAM

## Missing Inputs

## Ambiguities

## Risks

## Questions

## Required Revision

## Reviewed At
YYMMDDHH:mm:ss
