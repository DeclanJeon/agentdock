# Task Changelog

- Task ID:
- Parent Job ID:
- Team:
- Agent:

| Timestamp | Change Type | Changed By | Before | After | Reason | Approval Owner | Impact |
|---|---|---|---|---|---|---|---|
| YYMMDDHH:mm:ss | ADDED / REMOVED / MODIFIED |  |  |  |  |  |  |

## Change Type Guide

- ADDED: 새 task, 새 산출물, 새 요구사항이 추가됨
- REMOVED: task, 산출물, 요구사항이 제거됨
- MODIFIED: 범위, 방식, 우선순위, 수신 팀, 완료 기준이 변경됨
