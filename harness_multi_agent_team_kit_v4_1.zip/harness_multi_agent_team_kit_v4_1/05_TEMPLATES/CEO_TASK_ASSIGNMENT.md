# CEO TASK ASSIGNMENT

## From
CEO Agent

## To
[Team / Agent]

## Job ID

## Task ID

## Priority
P0 / P1 / P2 / P3

## Required Output

## Input Documents

## Definition of Done

## Handoff Target

## Created At
YYMMDDHH:mm:ss
