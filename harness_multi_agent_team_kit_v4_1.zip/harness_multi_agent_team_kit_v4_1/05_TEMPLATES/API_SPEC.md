# API Spec

## Endpoint

`METHOD /api/path`

## Purpose


## Request

```json
{
  "example": true
}
```

## Response

```json
{
  "ok": true
}
```

## Error Cases

| Status | Reason | Response |
|---:|---|---|
| 400 | Invalid input |  |
| 401 | Unauthorized |  |
| 500 | Server error |  |

## Security

- Auth:
- Rate Limit:
- Privacy:

## QA Notes

-
