# DECISION RECORD

## Decision ID
DEC-YYMMDD-000

## Job ID

## Task ID

## Status
PROPOSED / ACCEPTED / REJECTED / SUPERSEDED

## Context

## Options Considered

### Option A

### Option B

### Option C

## Decision

## Rationale

## Consequences

## Owner

## Decided At
YYMMDDHH:mm:ss
