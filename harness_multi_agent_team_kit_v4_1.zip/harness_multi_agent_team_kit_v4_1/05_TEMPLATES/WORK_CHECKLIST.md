# Work Checklist

- Task ID:
- Parent Job ID:
- Team:
- Agent:
- Created At: YYMMDDHH:mm:ss
- Status: CHECKLIST_CREATED

## 1. Work Scope

- [ ]
- [ ]
- [ ]

## 2. Out Of Scope

- [ ]
- [ ]

## 3. Required Inputs

- [ ]
- [ ]

## 4. Required Outputs

- [ ]
- [ ]
- [ ]

## 5. Validation Method

- [ ] Self-review completed
- [ ] Required document format followed
- [ ] Acceptance criteria checked
- [ ] Risks recorded
- [ ] Next receiver identified

## 6. Delegation Conditions

Delegate this task if:

- [ ] The request is outside this team's role
- [ ] Another team owns the required decision
- [ ] Required input must be produced by another team

## 7. Completion Criteria

This task is complete when:

- [ ] All required outputs are created
- [ ] `TASK_LOG.md` is updated
- [ ] `TASK_CHANGELOG.md` is updated if scope changed
- [ ] `COMPLETION_REPORT.md` is written
- [ ] `HANDOFF.md` is created for the next team
