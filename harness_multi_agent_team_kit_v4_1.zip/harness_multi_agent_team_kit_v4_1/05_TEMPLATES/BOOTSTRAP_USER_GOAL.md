# Bootstrap User Goal

Use this as the first message to CEO Agent.

```txt
User Goal:
<Describe the project, feature, bug, strategy, or document you want handled.>

CEO Agent:
1. Inspect the project context and repository structure.
2. Create a Job in .agent-work/07_JOBS.
3. Break the job into tasks.
4. Assign tasks to the correct teams.
5. Create RACI, Definition of Done, and handoff order.
6. Ask only for truly blocking missing information.
7. Use .agent-work for all durable coordination.
```
