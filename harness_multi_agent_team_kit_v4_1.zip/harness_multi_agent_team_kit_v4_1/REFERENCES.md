# References

## User Provided Videos

- https://www.youtube.com/watch?v=KtYs5W2yzjg
- https://youtu.be/3yyLg1xbQSs?si=d0i4VmX_zf-bvkkH
- https://www.youtube.com/watch?v=MpeuOAmctAg
- https://www.youtube.com/watch?v=Dyj9ShddyMw
- https://www.youtube.com/watch?v=k3WrvJIHJgg

## Related Concepts Used in This Kit

- Harness Engineering
- Agent = Model + Harness
- Thin Harness, Fat Skills
- tmux-based parallel agent sessions
- git worktree per agent/task
- Role boundary and delegation protocol
- Handoff-based collaboration
- Quality gate based release flow

## Notes

YouTube pages may not always expose full transcript or body text to automated readers. This kit is therefore written as a practical operating system based on the supplied topics, public metadata, and related publicly available discussions around harness engineering, tmux multi-agent workflows, and Codex/Claude-style coding agents.
